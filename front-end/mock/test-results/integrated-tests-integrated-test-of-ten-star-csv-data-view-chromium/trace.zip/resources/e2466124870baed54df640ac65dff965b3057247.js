import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7894ffce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7894ffce"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css";
import { REPLHistory } from "/src/components/REPLHistory.tsx";
import { REPLInput } from "/src/components/REPLInput.tsx";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [data, setData] = useState();
  const [isLoaded, setIsLoaded] = useState(false);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { history }, void 0, false, {
      fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPL.tsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPL.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, setHistory, data, setData, isLoaded, setIsLoaded }, void 0, false, {
      fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPL.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPL.tsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_s(REPL, "NjBjZKbfHNnnraOxsJuyxGJI9/k=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZk4sU0FBZ0RBLGdCQUFlO0FBQy9ELE9BQU87QUFDUCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBRTFCLHdCQUF3QkMsT0FBTztBQUFBQyxLQUFBO0FBQzdCLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUN0Qk4sU0FBeUIsRUFBRTtBQUMvQixRQUFNLENBQUNPLE1BQU1DLE9BQU8sSUFDaEJSLFNBQWlDO0FBQ3JDLFFBQU0sQ0FBQ1MsVUFBVUMsV0FBVyxJQUN4QlYsU0FBa0IsS0FBSztBQUUzQixTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkJBQUMsZUFBWSxXQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0I7QUFBQSxJQUMvQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSTtBQUFBLElBQ0osdUJBQUMsYUFBVSxTQUFrQixZQUF3QixNQUFZLFNBQ3RELFVBQW9CLGVBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDd0Q7QUFBQSxPQUoxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDSSxHQWhCdUJELE1BQUk7QUFBQVEsS0FBSlI7QUFBSSxJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJSRVBMSGlzdG9yeSIsIlJFUExJbnB1dCIsIlJFUEwiLCJfcyIsImhpc3RvcnkiLCJzZXRIaXN0b3J5IiwiZGF0YSIsInNldERhdGEiLCJpc0xvYWRlZCIsInNldElzTG9hZGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0Rpc3BhdGNoLCBSZWFjdEVsZW1lbnQsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZX0gZnJvbSAncmVhY3QnO1xuaW1wb3J0ICcuLi9zdHlsZXMvbWFpbi5jc3MnO1xuaW1wb3J0IHsgUkVQTEhpc3RvcnkgfSBmcm9tICcuL1JFUExIaXN0b3J5JztcbmltcG9ydCB7IFJFUExJbnB1dCB9IGZyb20gJy4vUkVQTElucHV0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUkVQTCgpIHtcbiAgY29uc3QgW2hpc3RvcnksIHNldEhpc3RvcnldID1cbiAgICAgIHVzZVN0YXRlPFJlYWN0RWxlbWVudFtdPihbXSlcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID1cbiAgICAgIHVzZVN0YXRlPHN0cmluZ1tdW10gfCB1bmRlZmluZWQ+KCk7XG4gIGNvbnN0IFtpc0xvYWRlZCwgc2V0SXNMb2FkZWRdID1cbiAgICAgIHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsXCI+IFxuICAgICAgPFJFUExIaXN0b3J5IGhpc3RvcnkgPXtoaXN0b3J5fS8+XG4gICAgICA8aHI+PC9ocj5cbiAgICAgIDxSRVBMSW5wdXQgaGlzdG9yeT17aGlzdG9yeX0gc2V0SGlzdG9yeT17c2V0SGlzdG9yeX0gZGF0YT17ZGF0YX0gc2V0RGF0YT17c2V0RGF0YX1cbiAgICAgICAgICAgICAgICAgaXNMb2FkZWQ9e2lzTG9hZGVkfSBzZXRJc0xvYWRlZD17c2V0SXNMb2FkZWR9Lz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3NpZGRhcnRoc2l0YXJhbWFuL0RvY3VtZW50cy9DU0NJMDMyMC9yZXBsLXNrc2l0YXJhLXNzZGh1bGlwL2Zyb250LWVuZC9tb2NrL3NyYy9jb21wb25lbnRzL1JFUEwudHN4In0=