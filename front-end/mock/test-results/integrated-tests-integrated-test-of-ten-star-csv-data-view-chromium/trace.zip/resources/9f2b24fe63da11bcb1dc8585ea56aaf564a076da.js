import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7894ffce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=7894ffce"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { REPLFunctionMap } from "/src/components/REPLFunction.tsx";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  let [isBrief, setMode] = useState(true);
  const [filePath, setFilePath] = useState("");
  const [hasHeader, setHasHeader] = useState("");
  let fp = "";
  let col;
  let val = "";
  function handleSubmit(commandString2) {
    var inputArray = commandString2.split(" ");
    var command = inputArray[0];
    if (command == "mode") {
      handleMode();
    } else if (REPLFunctionMap.has(command)) {
      var commandFunction = REPLFunctionMap.get(command);
      if (commandFunction) {
        var result = commandFunction(inputArray);
        addOutput(result);
      } else {
        props.setHistory([...props.history, buildResultTable([["Please enter a valid command"]])]);
      }
    } else {
      props.setHistory([...props.history, buildResultTable([["Please enter a valid command"]])]);
    }
    setCommandString("");
  }
  function handleMode() {
    setMode(!isBrief);
    props.setHistory([...props.history, buildResultTableMode([["Mode switched"]])]);
  }
  function buildResultTableHelper(result) {
    var tableString = "<table>";
    for (const row of result) {
      let rowString = "<tr>";
      for (const value of row) {
        rowString += "<td>" + value + "</td>";
      }
      rowString += "</tr>";
      tableString += rowString;
    }
    tableString += "</table>";
    return /* @__PURE__ */ jsxDEV("div", { dangerouslySetInnerHTML: {
      __html: tableString
    } }, void 0, false, {
      fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
      lineNumber: 64,
      columnNumber: 12
    }, this);
  }
  function buildResultTable(result) {
    var returnTable = buildResultTableHelper(result);
    if (isBrief) {
      return returnTable;
    } else {
      return /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Command: ",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
            lineNumber: 78,
            columnNumber: 31
          }, this),
          commandString,
          " "
        ] }, void 0, true, {
          fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
          lineNumber: 78,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Output: ",
          returnTable,
          " "
        ] }, void 0, true, {
          fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
          lineNumber: 78,
          columnNumber: 64
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
        lineNumber: 78,
        columnNumber: 14
      }, this);
    }
  }
  function buildResultTableMode(result) {
    var returnTable = buildResultTableHelper(result);
    if (!isBrief) {
      return returnTable;
    } else {
      return /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Command: ",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
            lineNumber: 86,
            columnNumber: 31
          }, this),
          commandString,
          " "
        ] }, void 0, true, {
          fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
          lineNumber: 86,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Output: ",
          returnTable,
          " "
        ] }, void 0, true, {
          fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
          lineNumber: 86,
          columnNumber: 64
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
        lineNumber: 86,
        columnNumber: 14
      }, this);
    }
  }
  function addOutput(result) {
    result.then((r) => buildResultTable(r)).then((response) => props.setHistory([...props.history, response]));
  }
  function checkIfFileEmpty() {
    if (!props.data) {
      return true;
    } else {
      if (props.data.length == 0) {
        return true;
      }
      for (const row in props.data) {
        if (row.length > 0) {
          return false;
        }
      }
      return true;
    }
  }
  document.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
      handleSubmit(commandString);
    } else if (event.metaKey || event.ctrlKey) {
      if (event.key === "b") {
        handleMode();
      } else if (event.key === "i") {
        document.getElementById("command-box").focus();
      }
    } else if (event.key === "ArrowUp") {
      document.getElementById("command-history").scrollBy(0, -40);
    } else if (event.key === "ArrowDown") {
      document.getElementById("command-history").scrollBy(0, 40);
    }
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
        lineNumber: 129,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
        lineNumber: 130,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
      lineNumber: 132,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleMode(), children: isBrief ? "Brief" : "Verbose" }, void 0, false, {
      fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
      lineNumber: 133,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx",
    lineNumber: 127,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "TzgNNVGl+2a4fjcfWzs2teNf6pg=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUVXOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJFWCxPQUFPO0FBQ1AsU0FBZ0RBLGdCQUFlO0FBQy9ELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFzQkMsdUJBQXNCO0FBYXJDLGdCQUFTQyxVQUFVQyxPQUF1QjtBQUFBQyxLQUFBO0FBRS9DLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlQLFNBQWlCLEVBQUU7QUFFN0QsTUFBSSxDQUFDUSxTQUFTQyxPQUFPLElBQUlULFNBQWtCLElBQUk7QUFFL0MsUUFBTSxDQUFDVSxVQUFVQyxXQUFXLElBQUlYLFNBQWlCLEVBQUU7QUFFbkQsUUFBTSxDQUFDWSxXQUFXQyxZQUFZLElBQUliLFNBQWlCLEVBQUU7QUFDckQsTUFBSWMsS0FBSztBQUNULE1BQUlDO0FBQ0osTUFBSUMsTUFBTTtBQUdWLFdBQVNDLGFBQWFYLGdCQUF1QjtBQUMzQyxRQUFJWSxhQUFhWixlQUFjYSxNQUFNLEdBQUc7QUFDeEMsUUFBSUMsVUFBVUYsV0FBVyxDQUFDO0FBRTFCLFFBQUlFLFdBQVcsUUFBUTtBQUNyQkMsaUJBQVc7QUFBQSxJQUNiLFdBQ1NuQixnQkFBZ0JvQixJQUFJRixPQUFPLEdBQUc7QUFDckMsVUFBSUcsa0JBQWtCckIsZ0JBQWdCc0IsSUFBSUosT0FBTztBQUNqRCxVQUFHRyxpQkFBaUI7QUFDbEIsWUFBSUUsU0FBU0YsZ0JBQWdCTCxVQUFVO0FBQ3ZDUSxrQkFBVUQsTUFBTTtBQUFBLE1BQ2xCLE9BQ0s7QUFDSHJCLGNBQU11QixXQUFXLENBQUMsR0FBR3ZCLE1BQU13QixTQUFTQyxpQkFBaUIsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDM0Y7QUFBQSxJQUNGLE9BQ0s7QUFDSHpCLFlBQU11QixXQUFXLENBQUMsR0FBR3ZCLE1BQU13QixTQUFTQyxpQkFBaUIsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDM0Y7QUFDQXRCLHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFFQSxXQUFTYyxhQUFhO0FBQ3BCWixZQUFRLENBQUNELE9BQU87QUFDaEJKLFVBQU11QixXQUFXLENBQUMsR0FBR3ZCLE1BQU13QixTQUFTRSxxQkFBcUIsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQ2hGO0FBRUEsV0FBU0MsdUJBQXVCTixRQUFvQjtBQUNsRCxRQUFJTyxjQUFjO0FBQ2xCLGVBQVdDLE9BQU9SLFFBQVE7QUFDeEIsVUFBSVMsWUFBWTtBQUNoQixpQkFBV0MsU0FBU0YsS0FBSztBQUN2QkMscUJBQWEsU0FBU0MsUUFBUTtBQUFBLE1BQ2hDO0FBQ0FELG1CQUFhO0FBQ2JGLHFCQUFlRTtBQUFBQSxJQUNqQjtBQUNBRixtQkFBZTtBQUNmLFdBQU8sdUJBQUMsU0FBSSx5QkFBeUI7QUFBQSxNQUFFSSxRQUFRSjtBQUFBQSxJQUFXLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcUQ7QUFBQSxFQUM5RDtBQU1BLFdBQVNILGlCQUFpQkosUUFBb0I7QUFDNUMsUUFBSVksY0FBY04sdUJBQXVCTixNQUFNO0FBQy9DLFFBQUdqQixTQUFTO0FBQ1YsYUFBTzZCO0FBQUFBLElBQ1QsT0FDSztBQUNILGFBQVEsdUJBQUMsU0FBSTtBQUFBLCtCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFJO0FBQUEsVUFBTS9CO0FBQUFBLFVBQWU7QUFBQSxhQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsUUFBSSx1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFTK0I7QUFBQUEsVUFBWTtBQUFBLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxXQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFO0FBQUEsSUFDekY7QUFBQSxFQUNGO0FBQ0EsV0FBU1AscUJBQXFCTCxRQUFvQjtBQUNoRCxRQUFJWSxjQUFjTix1QkFBdUJOLE1BQU07QUFDL0MsUUFBRyxDQUFDakIsU0FBUztBQUNYLGFBQU82QjtBQUFBQSxJQUNULE9BQ0s7QUFDSCxhQUFRLHVCQUFDLFNBQUk7QUFBQSwrQkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBSTtBQUFBLFVBQU0vQjtBQUFBQSxVQUFlO0FBQUEsYUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQUksdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBUytCO0FBQUFBLFVBQVk7QUFBQSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsV0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRTtBQUFBLElBQ3pGO0FBQUEsRUFDRjtBQUNBLFdBQVNYLFVBQVVELFFBQTZCO0FBQzlDQSxXQUNDYSxLQUFLQyxPQUFLVixpQkFBaUJVLENBQUMsQ0FBQyxFQUN6QkQsS0FBS0UsY0FBWXBDLE1BQU11QixXQUFXLENBQUMsR0FBR3ZCLE1BQU13QixTQUFTWSxRQUFRLENBQUMsQ0FBQztBQUFBLEVBQ3RFO0FBTUEsV0FBU0MsbUJBQW1CO0FBQzFCLFFBQUksQ0FBQ3JDLE1BQU1zQyxNQUFNO0FBQ2YsYUFBTztBQUFBLElBQ1QsT0FBTztBQUNMLFVBQUl0QyxNQUFNc0MsS0FBS0MsVUFBVSxHQUFHO0FBQzFCLGVBQU87QUFBQSxNQUNUO0FBQ0EsaUJBQVdWLE9BQU83QixNQUFNc0MsTUFBTTtBQUM1QixZQUFJVCxJQUFJVSxTQUFTLEdBQUc7QUFDbEIsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBQyxXQUFTQyxpQkFBaUIsV0FBVyxTQUFTQyxPQUFPO0FBQ25ELFFBQUdBLE1BQU1DLFFBQVEsU0FBUztBQUN4QjlCLG1CQUFhWCxhQUFhO0FBQUEsSUFDNUIsV0FDUXdDLE1BQU1FLFdBQVdGLE1BQU1HLFNBQVM7QUFDdEMsVUFBR0gsTUFBTUMsUUFBUSxLQUFLO0FBQ3BCMUIsbUJBQVc7QUFBQSxNQUNiLFdBQ1F5QixNQUFNQyxRQUFRLEtBQUs7QUFDekJILGlCQUFTTSxlQUFlLGFBQWEsRUFBR0MsTUFBTTtBQUFBLE1BQ2hEO0FBQUEsSUFDRixXQUNRTCxNQUFNQyxRQUFRLFdBQVc7QUFDL0JILGVBQVNNLGVBQWUsaUJBQWlCLEVBQUdFLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDN0QsV0FDUU4sTUFBTUMsUUFBUSxhQUFhO0FBQ2pDSCxlQUFTTSxlQUFlLGlCQUFpQixFQUFHRSxTQUFTLEdBQUcsRUFBRTtBQUFBLElBQzVEO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxtQkFDQyxPQUFPOUMsZUFDUCxVQUFVQyxrQkFDVixXQUFXLG1CQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHNkI7QUFBQSxTQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sU0FBUyxNQUFNVSxhQUFhWCxhQUFhLEdBQUcsc0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQ7QUFBQSxJQUMxRCx1QkFBQyxZQUFPLFNBQVMsTUFBTWUsV0FBVyxHQUMvQmIsb0JBQVUsVUFBVSxhQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNILEdBNUllRixXQUFTO0FBQUFrRCxLQUFUbEQ7QUFBUyxJQUFBa0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiUkVQTEZ1bmN0aW9uTWFwIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiaXNCcmllZiIsInNldE1vZGUiLCJmaWxlUGF0aCIsInNldEZpbGVQYXRoIiwiaGFzSGVhZGVyIiwic2V0SGFzSGVhZGVyIiwiZnAiLCJjb2wiLCJ2YWwiLCJoYW5kbGVTdWJtaXQiLCJpbnB1dEFycmF5Iiwic3BsaXQiLCJjb21tYW5kIiwiaGFuZGxlTW9kZSIsImhhcyIsImNvbW1hbmRGdW5jdGlvbiIsImdldCIsInJlc3VsdCIsImFkZE91dHB1dCIsInNldEhpc3RvcnkiLCJoaXN0b3J5IiwiYnVpbGRSZXN1bHRUYWJsZSIsImJ1aWxkUmVzdWx0VGFibGVNb2RlIiwiYnVpbGRSZXN1bHRUYWJsZUhlbHBlciIsInRhYmxlU3RyaW5nIiwicm93Iiwicm93U3RyaW5nIiwidmFsdWUiLCJfX2h0bWwiLCJyZXR1cm5UYWJsZSIsInRoZW4iLCJyIiwicmVzcG9uc2UiLCJjaGVja0lmRmlsZUVtcHR5IiwiZGF0YSIsImxlbmd0aCIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsImV2ZW50Iiwia2V5IiwibWV0YUtleSIsImN0cmxLZXkiLCJnZXRFbGVtZW50QnlJZCIsImZvY3VzIiwic2Nyb2xsQnkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQge0Rpc3BhdGNoLCBSZWFjdEVsZW1lbnQsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZX0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCB7UkVQTEZ1bmN0aW9uLCBSRVBMRnVuY3Rpb25NYXB9IGZyb20gXCIuL1JFUExGdW5jdGlvblwiO1xuXG4vL3NldHMgaW5wdXQgcHJvcHNcbmludGVyZmFjZSBSRVBMSW5wdXRQcm9wcyB7XG4gIGhpc3Rvcnk6IFJlYWN0RWxlbWVudFtdXG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPFJlYWN0RWxlbWVudFtdPj5cbiAgZGF0YTogc3RyaW5nW11bXSB8IHVuZGVmaW5lZDtcbiAgc2V0RGF0YTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nW11bXSB8IHVuZGVmaW5lZD4+O1xuICBpc0xvYWRlZDogYm9vbGVhbjtcbiAgc2V0SXNMb2FkZWQ6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPGJvb2xlYW4+Pjtcbn1cblxuLy9leHBvcnRzIFJFUExJbnB1dCBmb3Igb3V0c2lkZSB1c2VcbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XG4gIC8vZGVjbGFyZSBmdW5jdGlvbnMgYW5kIHZhcmlhYmxlc1xuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuXG4gIGxldCBbaXNCcmllZiwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcblxuICBjb25zdCBbZmlsZVBhdGgsIHNldEZpbGVQYXRoXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG5cbiAgY29uc3QgW2hhc0hlYWRlciwgc2V0SGFzSGVhZGVyXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGxldCBmcCA9IFwiXCI7XG4gIGxldCBjb2w7XG4gIGxldCB2YWwgPSBcIlwiO1xuXG4gIC8vaGFuZGxlU3VibWl0IGlzIHJ1biBldmVyeSB0aW1lIGEgYnV0dG9uIGlzIHByZXNzZWRcbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuICAgIHZhciBpbnB1dEFycmF5ID0gY29tbWFuZFN0cmluZy5zcGxpdChcIiBcIik7XG4gICAgdmFyIGNvbW1hbmQgPSBpbnB1dEFycmF5WzBdXG4gICAgLy8gRGVhbHMgd2l0aCBzd2l0Y2hpbmcgdGhlIG1vZGUgYmV0d2VlbiBicmllZiBhbmQgdmVyYm9zZVxuICAgIGlmIChjb21tYW5kID09IFwibW9kZVwiKSB7XG4gICAgICBoYW5kbGVNb2RlKClcbiAgICB9XG4gICAgZWxzZSBpZiAoUkVQTEZ1bmN0aW9uTWFwLmhhcyhjb21tYW5kKSkge1xuICAgICAgdmFyIGNvbW1hbmRGdW5jdGlvbiA9IFJFUExGdW5jdGlvbk1hcC5nZXQoY29tbWFuZClcbiAgICAgIGlmKGNvbW1hbmRGdW5jdGlvbikge1xuICAgICAgICB2YXIgcmVzdWx0ID0gY29tbWFuZEZ1bmN0aW9uKGlucHV0QXJyYXkpXG4gICAgICAgIGFkZE91dHB1dChyZXN1bHQpXG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgcHJvcHMuc2V0SGlzdG9yeShbLi4ucHJvcHMuaGlzdG9yeSwgYnVpbGRSZXN1bHRUYWJsZShbW1wiUGxlYXNlIGVudGVyIGEgdmFsaWQgY29tbWFuZFwiXV0pXSlcbiAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBwcm9wcy5zZXRIaXN0b3J5KFsuLi5wcm9wcy5oaXN0b3J5LCBidWlsZFJlc3VsdFRhYmxlKFtbXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBjb21tYW5kXCJdXSldKVxuICAgIH1cbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpXG4gIH1cblxuICBmdW5jdGlvbiBoYW5kbGVNb2RlKCkge1xuICAgIHNldE1vZGUoIWlzQnJpZWYpO1xuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIGJ1aWxkUmVzdWx0VGFibGVNb2RlKFtbXCJNb2RlIHN3aXRjaGVkXCJdXSldKVxuICB9XG5cbiAgZnVuY3Rpb24gYnVpbGRSZXN1bHRUYWJsZUhlbHBlcihyZXN1bHQ6IHN0cmluZ1tdW10pIHtcbiAgICB2YXIgdGFibGVTdHJpbmcgPSBcIjx0YWJsZT5cIjtcbiAgICBmb3IgKGNvbnN0IHJvdyBvZiByZXN1bHQpIHtcbiAgICAgIGxldCByb3dTdHJpbmcgPSBcIjx0cj5cIjtcbiAgICAgIGZvciAoY29uc3QgdmFsdWUgb2Ygcm93KSB7XG4gICAgICAgIHJvd1N0cmluZyArPSBcIjx0ZD5cIiArIHZhbHVlICsgXCI8L3RkPlwiO1xuICAgICAgfVxuICAgICAgcm93U3RyaW5nICs9IFwiPC90cj5cIjtcbiAgICAgIHRhYmxlU3RyaW5nICs9IHJvd1N0cmluZztcbiAgICB9XG4gICAgdGFibGVTdHJpbmcgKz0gXCI8L3RhYmxlPlwiO1xuICAgIHJldHVybiA8ZGl2IGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogdGFibGVTdHJpbmd9fS8+XG4gIH1cbiAgLyoqXG4gICAqIFRoaXMgZnVuY3Rpb24gYnVpbGRzIGEgaHRtbCB0YWJsZSBnaXZlbiB0aGUgZmlsZURhdGEgb3IganVzdCB0aGUgb3V0cHV0IHRoYXQgc2hvdWxkIGJlIGRpc3BsYXllZFxuICAgKiBAcGFyYW0gcmVzdWx0IGlzIHRoZSAyZCBzdHJpbmcgYXJyYXkgdGhhdCB3aWxsIGJlIGNvbnZlcnRlZCB0byBhIGh0bWwgdGFibGVcbiAgICogQHJldHVybnMgYSBodG1sIHRhYmxlIGFzIGEgc3RyaW5nXG4gICAqL1xuICBmdW5jdGlvbiBidWlsZFJlc3VsdFRhYmxlKHJlc3VsdDogc3RyaW5nW11bXSkge1xuICAgIHZhciByZXR1cm5UYWJsZSA9IGJ1aWxkUmVzdWx0VGFibGVIZWxwZXIocmVzdWx0KVxuICAgIGlmKGlzQnJpZWYpIHtcbiAgICAgIHJldHVybiByZXR1cm5UYWJsZVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHJldHVybiAoPGRpdj48cD5Db21tYW5kOiA8YnI+PC9icj57Y29tbWFuZFN0cmluZ317XCIgXCJ9PC9wPjxwPk91dHB1dDoge3JldHVyblRhYmxlfSA8L3A+PC9kaXY+KVxuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBidWlsZFJlc3VsdFRhYmxlTW9kZShyZXN1bHQ6IHN0cmluZ1tdW10pIHtcbiAgICB2YXIgcmV0dXJuVGFibGUgPSBidWlsZFJlc3VsdFRhYmxlSGVscGVyKHJlc3VsdClcbiAgICBpZighaXNCcmllZikge1xuICAgICAgcmV0dXJuIHJldHVyblRhYmxlXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgcmV0dXJuICg8ZGl2PjxwPkNvbW1hbmQ6IDxicj48L2JyPntjb21tYW5kU3RyaW5nfXtcIiBcIn08L3A+PHA+T3V0cHV0OiB7cmV0dXJuVGFibGV9IDwvcD48L2Rpdj4pXG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGFkZE91dHB1dChyZXN1bHQ6IFByb21pc2U8c3RyaW5nW11bXT4pIHtcbiAgICByZXN1bHRcbiAgICAudGhlbihyID0+IGJ1aWxkUmVzdWx0VGFibGUocikpXG4gICAgICAgIC50aGVuKHJlc3BvbnNlID0+IHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIHJlc3BvbnNlXSkpXG4gIH1cblxuICAvKipcbiAgICogVGhpcyBmdW5jdGlvbiBjaGVja3MgaWYgdGhlIGZpbGUgaXMgZW1wdHkgb3Igbm90XG4gICAqIEByZXR1cm5zIHRydWUgaWYgaXQgaXMgZW1wdHkgYW5kIGZhbHNlIG90aGVyd2lzZVxuICAgKi9cbiAgZnVuY3Rpb24gY2hlY2tJZkZpbGVFbXB0eSgpIHtcbiAgICBpZiAoIXByb3BzLmRhdGEpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAocHJvcHMuZGF0YS5sZW5ndGggPT0gMCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3Qgcm93IGluIHByb3BzLmRhdGEpIHtcbiAgICAgICAgaWYgKHJvdy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBmdW5jdGlvbihldmVudCkge1xuICAgIGlmKGV2ZW50LmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZylcbiAgICB9XG4gICAgZWxzZSBpZihldmVudC5tZXRhS2V5IHx8IGV2ZW50LmN0cmxLZXkpIHtcbiAgICAgIGlmKGV2ZW50LmtleSA9PT0gXCJiXCIpIHtcbiAgICAgICAgaGFuZGxlTW9kZSgpO1xuICAgICAgfVxuICAgICAgZWxzZSBpZihldmVudC5rZXkgPT09IFwiaVwiKSB7XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29tbWFuZC1ib3hcIikhLmZvY3VzKCk7XG4gICAgICB9XG4gICAgfVxuICAgIGVsc2UgaWYoZXZlbnQua2V5ID09PSBcIkFycm93VXBcIikge1xuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb21tYW5kLWhpc3RvcnlcIikhLnNjcm9sbEJ5KDAsIC00MClcbiAgICB9XG4gICAgZWxzZSBpZihldmVudC5rZXkgPT09IFwiQXJyb3dEb3duXCIpIHtcbiAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29tbWFuZC1oaXN0b3J5XCIpIS5zY3JvbGxCeSgwLCA0MClcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCI+XG4gICAgICA8ZmllbGRzZXQ+XG4gICAgICAgIDxsZWdlbmQ+RW50ZXIgYSBjb21tYW5kOjwvbGVnZW5kPlxuICAgICAgICA8Q29udHJvbGxlZElucHV0XG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgYXJpYUxhYmVsPXtcIkNvbW1hbmQgaW5wdXRcIn1cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKX0+U3VibWl0PC9idXR0b24+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1vZGUoKX0+XG4gICAgICAgIHtpc0JyaWVmID8gXCJCcmllZlwiIDogXCJWZXJib3NlXCJ9XG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3NpZGRhcnRoc2l0YXJhbWFuL0RvY3VtZW50cy9DU0NJMDMyMC9yZXBsLXNrc2l0YXJhLXNzZGh1bGlwL2Zyb250LWVuZC9tb2NrL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3gifQ==