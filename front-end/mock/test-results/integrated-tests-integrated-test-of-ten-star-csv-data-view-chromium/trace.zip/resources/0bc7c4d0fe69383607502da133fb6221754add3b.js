import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7894ffce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ControlledInput({
  value,
  setValue,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "Enter command here!", onChange: (ev) => setValue(ev.target.value), "aria-label": ariaLabel, id: "command-box" }, void 0, false, {
    fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/ControlledInput.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRO0FBakJSLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZWxCLGdCQUFTQSxnQkFBZ0I7QUFBQSxFQUFDQztBQUFBQSxFQUFPQztBQUFBQSxFQUFVQztBQUErQixHQUFHO0FBQ2xGLFNBQ0ksdUJBQUMsV0FDRyxNQUFLLFFBQ0wsV0FBVSxvQkFDVixPQUNBLGFBQVksdUJBQ1osVUFBV0MsUUFBT0YsU0FBU0UsR0FBR0MsT0FBT0osS0FBSyxHQUMxQyxjQUFZRSxXQUNaLElBQUcsaUJBUFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9vQjtBQUcxQjtBQUFDRyxLQVplTjtBQUFlLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb250cm9sbGVkSW5wdXQiLCJ2YWx1ZSIsInNldFZhbHVlIiwiYXJpYUxhYmVsIiwiZXYiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyb2xsZWRJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvbWFpbi5jc3MnO1xuaW1wb3J0IFJlYWN0LCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gJ3JlYWN0JztcblxuLy8gUmVtZW1iZXIgdGhhdCBwYXJhbWV0ZXIgbmFtZXMgZG9uJ3QgbmVjZXNzYXJpbHkgbmVlZCB0byBvdmVybGFwO1xuLy8gSSBjb3VsZCB1c2UgZGlmZmVyZW50IHZhcmlhYmxlIG5hbWVzIGluIHRoZSBhY3R1YWwgZnVuY3Rpb24uXG5pbnRlcmZhY2UgQ29udHJvbGxlZElucHV0UHJvcHMge1xuICAgIHZhbHVlOiBzdHJpbmcsIFxuICAgIC8vIFRoaXMgdHlwZSBjb21lcyBmcm9tIFJlYWN0K1R5cGVTY3JpcHQuIFZTQ29kZSBjYW4gc3VnZ2VzdCB0aGVzZS5cbiAgICAvLyAgIENvbmNyZXRlbHksIHRoaXMgbWVhbnMgXCJhIGZ1bmN0aW9uIHRoYXQgc2V0cyBhIHN0YXRlIGNvbnRhaW5pbmcgYSBzdHJpbmdcIlxuICAgIHNldFZhbHVlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PixcbiAgICBhcmlhTGFiZWw6IHN0cmluZ1xuICB9XG4gIFxuICAvLyBJbnB1dCBib3hlcyBjb250YWluIHN0YXRlLiBXZSB3YW50IHRvIG1ha2Ugc3VyZSBSZWFjdCBpcyBtYW5hZ2luZyB0aGF0IHN0YXRlLFxuICAvLyAgIHNvIHdlIGhhdmUgYSBzcGVjaWFsIGNvbXBvbmVudCB0aGF0IHdyYXBzIHRoZSBpbnB1dCBib3guXG4gIGV4cG9ydCBmdW5jdGlvbiBDb250cm9sbGVkSW5wdXQoe3ZhbHVlLCBzZXRWYWx1ZSwgYXJpYUxhYmVsfTogQ29udHJvbGxlZElucHV0UHJvcHMpIHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlcGwtY29tbWFuZC1ib3hcIlxuICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjb21tYW5kIGhlcmUhXCJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXYpID0+IHNldFZhbHVlKGV2LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBhcmlhLWxhYmVsPXthcmlhTGFiZWx9XG4gICAgICAgICAgICBpZD1cImNvbW1hbmQtYm94XCJcbiAgICAgICAgLz5cbiAgICApO1xuICB9Il0sImZpbGUiOiIvVXNlcnMvc2lkZGFydGhzaXRhcmFtYW4vRG9jdW1lbnRzL0NTQ0kwMzIwL3JlcGwtc2tzaXRhcmEtc3NkaHVsaXAvZnJvbnQtZW5kL21vY2svc3JjL2NvbXBvbmVudHMvQ29udHJvbGxlZElucHV0LnRzeCJ9