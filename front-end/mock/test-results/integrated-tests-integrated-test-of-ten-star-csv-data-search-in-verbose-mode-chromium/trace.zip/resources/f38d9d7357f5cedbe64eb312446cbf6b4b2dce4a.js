import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7894ffce"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", "aria-label": "Command History", children: props.history.map((command, index) => /* @__PURE__ */ jsxDEV("p", { children: command }, void 0, false, {
    fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLHistory.tsx",
    lineNumber: 8,
    columnNumber: 52
  }, this)) }, void 0, false, {
    fileName: "/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLHistory.tsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/siddarthsitaraman/Documents/CSCI0320/repl-sksitara-ssdhulip/front-end/mock/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU21EO0FBVG5ELE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTXBCLGdCQUFTQSxZQUFZQyxPQUEwQjtBQUNsRCxTQUNJLHVCQUFDLFNBQUksV0FBVSxnQkFBZSxjQUFXLG1CQUNwQ0EsZ0JBQU1DLFFBQVFDLElBQUksQ0FBQ0MsU0FBU0MsVUFBVSx1QkFBQyxPQUFHRCxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVksQ0FBSSxLQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFUjtBQUFDRSxLQU5lTjtBQUFXLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSRVBMSGlzdG9yeSIsInByb3BzIiwiaGlzdG9yeSIsIm1hcCIsImNvbW1hbmQiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL21haW4uY3NzJztcbmltcG9ydCB7UmVhY3RFbGVtZW50fSBmcm9tIFwicmVhY3RcIjtcblxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHN7XG4gICAgaGlzdG9yeTogUmVhY3RFbGVtZW50W11cbn1cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSGlzdG9yeShwcm9wcyA6IFJFUExIaXN0b3J5UHJvcHMpIHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaGlzdG9yeVwiIGFyaWEtbGFiZWw9XCJDb21tYW5kIEhpc3RvcnlcIj5cbiAgICAgICAgICAgIHtwcm9wcy5oaXN0b3J5Lm1hcCgoY29tbWFuZCwgaW5kZXgpID0+IDxwPntjb21tYW5kfTwvcD4pfVxuICAgICAgICA8L2Rpdj5cbiAgICApO1xufSJdLCJmaWxlIjoiL1VzZXJzL3NpZGRhcnRoc2l0YXJhbWFuL0RvY3VtZW50cy9DU0NJMDMyMC9yZXBsLXNrc2l0YXJhLXNzZGh1bGlwL2Zyb250LWVuZC9tb2NrL3NyYy9jb21wb25lbnRzL1JFUExIaXN0b3J5LnRzeCJ9